package com.QRCode.entity;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="QRCode")
@EntityListeners(AuditingEntityListener.class)
public class QRCode {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "qr_code_data", nullable = false)
    private String qrCodeData;

    @Column(name = "updated_datetime", nullable = false)
    private Date updatedDtTime;

    @Column(name = "updated_by", nullable = false)
    private String updatedBy;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getQrCodeData() {
        return qrCodeData;
    }

    public void setQrCodeData(String qrCodeData) {
        this.qrCodeData = qrCodeData;
    }

    public Date getUpdatedDtTime() {
        return updatedDtTime;
    }

    public void setUpdatedDtTime(Date updatedDtTime) {
        this.updatedDtTime = updatedDtTime;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
}
