package com.QRCode.entity;

import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

public class QRCodeRepositoryImpl implements QRCodeRepository{

    public Boolean upload(String qrCodeFile){
        return true;
    }
    public List<QRCode> findAll(Sort qrCode){
        List<QRCode> lstQrCode = new ArrayList<>();
        return lstQrCode;
    }

    public List<QRCode> findAll(){
        List<QRCode> lstQrCode = new ArrayList<>();
        return lstQrCode;
    }

    public List<QRCode> findAll(String id){
        List<QRCode> lstQrCode = new ArrayList<>();
        return lstQrCode;
    }

    public List<QRCode> findAllById(String id){
        List<QRCode> lstQrCode = new ArrayList<>();
        return lstQrCode;
    }

    public List<QRCode> findAllById(List<QRCode> qrCodeList){
        List<QRCode> lstQrCode = new ArrayList<>();
        return lstQrCode;
    }
}
