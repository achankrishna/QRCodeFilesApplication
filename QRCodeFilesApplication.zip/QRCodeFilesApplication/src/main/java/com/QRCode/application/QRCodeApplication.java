package com.QRCode.application;

import com.QRCode.controller.QRCodeController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QRCodeApplication {

	@Autowired
	QRCodeController qrCodeController;
	public static void main(String[] args) {

		SpringApplication.run(QRCodeApplication.class, args);
		//qrCodeController.upload();
	}

}
