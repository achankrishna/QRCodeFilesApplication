package com.QRCode.controller;

import com.QRCode.entity.QRCodeRepository;
import com.QRCode.service.QRCodeService;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/qr/api")
public class QRCodeController {

    @Autowired
    private QRCodeService qrCodeService;

    @GetMapping("upload")
    public Boolean upload(File qrCodeImage) throws IOException{

        return qrCodeService.upload(qrCodeImage);
    }
}
