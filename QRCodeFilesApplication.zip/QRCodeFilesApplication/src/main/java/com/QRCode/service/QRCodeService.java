package com.QRCode.service;

import com.QRCode.entity.QRCodeRepository;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

@Service
public class QRCodeService {

    @Autowired
    private QRCodeRepository qrCodeRepository;
    @Bean
    public Boolean upload(File qrCodeImage) throws IOException {
        Boolean isFileUploaded = false;
        Result result = null;
        BufferedImage bufferredImage = ImageIO.read(qrCodeImage);
        LuminanceSource source = new BufferedImageLuminanceSource(bufferredImage);
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

        try {
            result = new MultiFormatReader().decode(bitmap);
            isFileUploaded = qrCodeRepository.upload(result.getText());
        } catch (NotFoundException e) {
            System.out.println("There is no QR code in the image");
        }
        return isFileUploaded;
    }
}

